document.addEventListener("DOMContentLoaded", function() {
    const featuredImage = document.getElementById("featuredImage");
    const imageTitle = document.getElementById("imageTitle");
    const thumbnailList = document.getElementById("thumbnailList");

    thumbnailList.addEventListener("click", function(event) {
        if (event.target.tagName === "IMG") {
            const newSrc = event.target.src.replace("-small.jpg", "-large.jpg");
            const newTitle = event.target.alt;
            featuredImage.src = newSrc;
            imageTitle.textContent = newTitle;

            // Remove active class from all thumbnails
            const thumbnails = thumbnailList.querySelectorAll("img");
            thumbnails.forEach(function(thumbnail) {
                thumbnail.classList.remove("active");
            });

            // Add active class to the clicked thumbnail
            event.target.classList.add("active");
        }
    });
});
